percent = float(input('input percent of test in numbers'))

if 90 <= percent < 101:
    print('Student is grade 9')
elif 80 <= percent < 90:
    print('Student is grade 8')
elif 70 <= percent < 80:
    print('Student is grade 7')
elif 60 <= percent < 70:
    print('Student is grade 6')
elif 50 <= percent < 60:
    print('Student is grade 5')
elif 40 <= percent < 50:
    print('Student is grade 4')
elif 30 <= percent < 40:
    print('Student is grade 3')
elif 20 <= percent < 30:
    print('Student is grade 2')
elif 10 <= percent < 20:
    print('Student is grade 1')
elif 0 <= percent < 10:
    print('Student is ungraded')
else:
    print('invalid integer')
